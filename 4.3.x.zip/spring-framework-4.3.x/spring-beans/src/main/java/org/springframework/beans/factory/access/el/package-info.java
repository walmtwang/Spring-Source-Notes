/**
 * Support classes for accessing a Spring BeanFactory from Unified EL.
 */
package org.springframework.beans.factory.access.el;
